Project 5


By Dylan Olthoff and Rylan Casanova


1. Install Ubuntu
2. Install g++ and packages to get openGL working in Ubuntu
3. Compile the project5 file by doing $g++ project5.cpp -o project5scene -lglut -lGLU -lGL
4. Run project5 by doing $./project5scene
5. Click and hold left-clik to move the camera around the scene